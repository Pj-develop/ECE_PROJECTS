# Arduino_Final_MiniProject
Arduino project simulated using proteus.
