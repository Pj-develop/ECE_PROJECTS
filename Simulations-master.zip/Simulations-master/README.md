                             """""""""""Ujamaa Tribe GSM Light Automated Control System"""""""""""""""""""""""""""

The above simulated system has been developed with the challenge of enabling remote light control in rural areas, and as well as helping the elderly and handicapped to be able to control lights both remotely and in-house. The system has been simulated using Proteus software.
Any improvements to the above system are highly welcomed.


