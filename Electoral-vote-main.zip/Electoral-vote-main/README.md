# Electoral-vote-
Microprocessor final project at AUT
